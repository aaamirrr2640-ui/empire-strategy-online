@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js نصب نیست. ابتدا Node.js را نصب کنید.
  pause
  exit /b 1
)
node server.js
pause
