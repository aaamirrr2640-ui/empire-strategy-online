#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js نصب نیست. در Termux اجرا کنید: pkg update && pkg install nodejs"
  exit 1
fi
node server.js
